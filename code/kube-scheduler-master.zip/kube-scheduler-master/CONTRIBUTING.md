# Contributing guidelines

Do not open pull requests directly against this repository, they will be ignored. Instead, please open pull requests against [kubernetes/kubernetes](https://git.k8s.io/kubernetes/).  Please follow the same [contributing guide](https://git.k8s.io/kubernetes/CONTRIBUTING.md) you would follow for any other pull request made to kubernetes/kubernetes.

This repository is published from [kubernetes/kubernetes/staging/src/k8s.io/kube-scheduler](https://git.k8s.io/kubernetes/staging/src/k8s.io/kube-scheduler) by the [kubernetes publishing-bot](https://git.k8s.io/publishing-bot).

Please see [Staging Directory and Publishing](https://git.k8s.io/community/contributors/devel/sig-architecture/staging.md) for more information
