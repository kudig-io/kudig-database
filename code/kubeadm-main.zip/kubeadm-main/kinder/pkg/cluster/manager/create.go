/*
Copyright 2019 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package manager

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/pkg/errors"
	log "github.com/sirupsen/logrus"

	"k8s.io/apimachinery/pkg/util/wait"

	"k8s.io/kubeadm/kinder/pkg/cluster/status"
	"k8s.io/kubeadm/kinder/pkg/constants"
	"k8s.io/kubeadm/kinder/pkg/cri/host"
	"k8s.io/kubeadm/kinder/pkg/cri/nodes"
	"k8s.io/kubeadm/kinder/pkg/exec"
)

// CreateOptions holds all the options used at create time
type CreateOptions struct {
	controlPlanes        int
	workers              int
	image                string
	externalLoadBalancer bool
	externalEtcd         bool
	retain               bool
	volumes              []string
}

// CreateOption is a configuration option supplied to Create
type CreateOption func(*CreateOptions)

// ControlPlanes sets the number of control plane nodes for create
func ControlPlanes(controlPlanes int) CreateOption {
	return func(c *CreateOptions) {
		c.controlPlanes = controlPlanes
	}
}

// Workers sets the number of worker nodes for create
func Workers(workers int) CreateOption {
	return func(c *CreateOptions) {
		c.workers = workers
	}
}

// Image sets the image for create
func Image(image string) CreateOption {
	return func(c *CreateOptions) {
		c.image = image
	}
}

// ExternalEtcd instruct create to add an external etcd to the cluster
func ExternalEtcd(externalEtcd bool) CreateOption {
	return func(c *CreateOptions) {
		c.externalEtcd = externalEtcd
	}
}

// ExternalLoadBalancer instruct create to add an external loadbalancer to the cluster.
// NB. this happens automatically when there are more than two control plane instances, but with this flag
// it is possible to override the default behaviour
func ExternalLoadBalancer(externalLoadBalancer bool) CreateOption {
	return func(c *CreateOptions) {
		c.externalLoadBalancer = externalLoadBalancer
	}
}

// Retain option instructs create cluster to preserve node in case of errors for debugging purposes
func Retain(retain bool) CreateOption {
	return func(c *CreateOptions) {
		c.retain = retain
	}
}

// Volumes option instructs create cluster to add volumes to the node containers
func Volumes(volumes []string) CreateOption {
	return func(c *CreateOptions) {
		c.volumes = volumes
	}
}

// CreateCluster creates a new kinder cluster
func CreateCluster(clusterName string, options ...CreateOption) error {
	flags := &CreateOptions{}
	for _, o := range options {
		o(flags)
	}

	// Check if the cluster name already exists
	known, err := status.IsKnown(clusterName)
	if err != nil {
		return err
	}
	if known {
		return errors.Errorf("a cluster with the name %q already exists", clusterName)
	}

	fmt.Printf("Creating cluster %q ...\n", clusterName)

	// attempt to explicitly pull the required node image if it doesn't exist locally
	// we don't care if this errors, we'll still try to run which also pulls
	ensureNodeImage(flags.image)

	handleErr := func(err error) error {
		// In case of errors nodes are deleted (except if retain is explicitly set)
		if !flags.retain {
			if c, err := status.FromDocker(clusterName); err != nil {
				log.Error(err)
			} else {
				for _, n := range c.AllNodes() {
					if err := exec.NewHostCmd(
						"docker",
						"rm",
						"-f", // force the container to be deleted now
						"-v", // delete volumes
						n.Name(),
					).Run(); err != nil {
						return errors.Wrapf(err, "failed to delete node %s", n.Name())
					}
				}
			}
		}
		log.Error(err)
		return err
	}

	// Create node containers as defined in the kind config
	if err := createNodes(
		clusterName,
		flags,
	); err != nil {
		return handleErr(errors.Wrap(err, "error creating nodes"))
	}

	fmt.Println()
	fmt.Printf("Nodes creation complete. You can now continue creating a Kubernetes cluster using\n")
	fmt.Printf("kinder do, the kinder swiss knife 🚀!\n")

	return nil
}

func createNodes(clusterName string, flags *CreateOptions) error {
	// compute the desired nodes, and inform the user that we are setting them up
	desiredNodes := nodesToCreate(clusterName, flags)
	numberOfNodes := len(desiredNodes)
	if flags.externalEtcd {
		numberOfNodes++
	}
	fmt.Printf("Preparing nodes %s\n", strings.Repeat("📦", numberOfNodes))

	// detect CRI runtime installed into images before actually creating nodes
	runtime, err := status.InspectCRIinImage(flags.image)
	if err != nil {
		log.Errorf("Error detecting CRI for images %s! %v", flags.image, err)
		return err
	}
	log.Infof("Detected %s container runtime for image %s", runtime, flags.image)

	createHelper, err := nodes.NewCreateHelper(runtime)
	if err != nil {
		log.Errorf("Error creating NewCreateHelper for CRI %s! %v", flags.image, err)
		return err
	}

	// create all of the node containers
	log.Info("Creating nodes...")
	for _, desiredNode := range desiredNodes {
		var err error
		switch desiredNode.Role {
		case constants.ExternalLoadBalancerNodeRoleValue:
			err = createHelper.CreateExternalLoadBalancer(clusterName, desiredNode.Name)
		case constants.ControlPlaneNodeRoleValue, constants.WorkerNodeRoleValue:
			err = createHelper.CreateNode(clusterName, desiredNode.Name, flags.image, desiredNode.Role, flags.volumes)
		}
		if err != nil {
			return errors.Wrapf(err, "error creating node %v", desiredNode)
		}
	}

	// add an external etcd if explicitly requested
	if flags.externalEtcd {
		log.Info("Getting required etcd image...")
		c, err := status.FromDocker(clusterName)
		if err != nil {
			return err
		}

		etcdImage, err := c.BootstrapControlPlane().EtcdImage()
		if err != nil {
			return err
		}

		// attempt to explicitly pull the etcdImage if it doesn't exist locally
		// we don't care if this errors, we'll still try to run which also pulls
		_, _ = host.PullImage(etcdImage, 4)

		log.Info("Creating external etcd...")
		if err := createHelper.CreateExternalEtcd(clusterName, fmt.Sprintf("%s-etcd", clusterName), etcdImage); err != nil {
			return err
		}
	}

	// wait for all node containers to have a Running status
	log.Info("Waiting for all nodes to start...")
	timeout := time.Second * 40
	for _, n := range desiredNodes {
		var lastErr error
		log.Infof("Waiting for node %s to start...", n.Name)
		err = wait.PollUntilContextTimeout(context.Background(), time.Second*1, timeout, true, func(ctx context.Context) (bool, error) {
			lines, err := exec.NewHostCmd(
				"docker",
				"container",
				"inspect",
				"-f",
				"'{{.State.Running}}'",
				n.Name,
			).RunAndCapture()
			if err == nil && len(lines) > 0 && lines[0] == `'true'` {
				return true, nil
			}
			lastErr = errors.Errorf("node state is not Running, error: %v, output lines: %+v, ", err, lines)
			return false, nil
		})
		if err != nil {
			return errors.Wrapf(lastErr, "node %s did not start in %v", n.Name, timeout)
		}
	}

	// get the cluster
	c, err := status.FromDocker(clusterName)
	if err != nil {
		return err
	}

	c.Settings = &status.ClusterSettings{
		IPFamily: status.IPv4Family, // only IPv4 is tested with kinder
	}

	// TODO: the cluster and node settings are currently unused by kinder
	// Enable these writes if settings have to stored on the nodes
	//
	// // write to the nodes the cluster settings that will be re-used by kinder during the cluster lifecycle.
	//
	// if err := c.WriteSettings(); err != nil {
	// 	return err
	// }
	//
	// for _, n := range c.K8sNodes() {
	// 	if err := n.WriteNodeSettings(&status.NodeSettings{}); err != nil {
	// 		return err
	// 	}
	// }

	return nil
}

// nodeSpec describes a node to create purely from the container aspect
// this does not include eg starting kubernetes (see actions for that)
type nodeSpec struct {
	Name string
	Role string
}

// nodesToCreate return the list of nodes to create for the cluster
func nodesToCreate(clusterName string, flags *CreateOptions) []nodeSpec {
	var desiredNodes []nodeSpec

	// prepare nodes explicitly
	for n := range flags.controlPlanes {
		role := constants.ControlPlaneNodeRoleValue
		desiredNode := nodeSpec{
			Name: fmt.Sprintf("%s-%s-%d", clusterName, role, n+1),
			Role: role,
		}
		desiredNodes = append(desiredNodes, desiredNode)
	}
	for n := range flags.workers {
		role := constants.WorkerNodeRoleValue
		desiredNode := nodeSpec{
			Name: fmt.Sprintf("%s-%s-%d", clusterName, role, n+1),
			Role: role,
		}
		desiredNodes = append(desiredNodes, desiredNode)
	}

	// add an external load balancer if explicitly requested or if there are multiple control planes
	if flags.externalLoadBalancer || flags.controlPlanes > 1 {
		role := constants.ExternalLoadBalancerNodeRoleValue
		desiredNodes = append(desiredNodes, nodeSpec{
			Name: fmt.Sprintf("%s-lb", clusterName),
			Role: role,
		})
	}

	return desiredNodes
}

// ensureNodeImage ensures that the node image used by the create is present
func ensureNodeImage(image string) {
	fmt.Printf("Ensuring node image (%s) 🖼\n", image)

	// attempt to explicitly pull the image if it doesn't exist locally
	// we don't care if this errors, we'll still try to run which also pulls
	_, _ = host.PullImage(image, 4)
}
