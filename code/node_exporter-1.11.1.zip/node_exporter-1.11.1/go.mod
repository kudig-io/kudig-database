module github.com/prometheus/node_exporter

go 1.25.0

require (
	github.com/alecthomas/kingpin/v2 v2.4.0
	github.com/beevik/ntp v1.5.0
	github.com/coreos/go-systemd/v22 v22.7.0
	github.com/dennwc/btrfs v0.0.0-20260222081608-edfb8b9e4f55
	github.com/ema/qdisc v1.0.0
	github.com/godbus/dbus/v5 v5.2.2
	github.com/hashicorp/go-envparse v0.1.0
	github.com/hodgesds/perf-utils v0.7.0
	github.com/illumos/go-kstat v0.0.0-20210513183136-173c9b0a9973
	github.com/jsimonetti/rtnetlink/v2 v2.2.0
	github.com/lufia/iostat v1.2.1
	github.com/mattn/go-xmlrpc v0.0.3
	github.com/mdlayher/ethtool v0.6.0
	github.com/mdlayher/netlink v1.10.0
	github.com/mdlayher/wifi v0.7.2
	github.com/opencontainers/selinux v1.13.1
	github.com/power-devops/perfstat v0.0.0-20240221224432-82ca36839d55
	github.com/prometheus-community/go-runit v0.1.0
	github.com/prometheus/client_golang v1.23.2
	github.com/prometheus/client_model v0.6.2
	github.com/prometheus/common v0.67.5
	github.com/prometheus/exporter-toolkit v0.16.0
	github.com/prometheus/procfs v0.20.1
	github.com/safchain/ethtool v0.7.0
	golang.org/x/sys v0.42.0
	howett.net/plist v1.0.1
)

require (
	cyphar.com/go-pathrs v0.2.2 // indirect
	github.com/alecthomas/units v0.0.0-20240927000941-0f3dac36c52b // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/cyphar/filepath-securejoin v0.6.1 // indirect
	github.com/dennwc/ioctl v1.0.1-0.20181021180353-017804252068 // indirect
	github.com/golang-jwt/jwt/v5 v5.3.0 // indirect
	github.com/google/go-cmp v0.7.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/jpillora/backoff v1.0.0 // indirect
	github.com/kylelemons/godebug v1.1.0 // indirect
	github.com/mdlayher/genetlink v1.3.2 // indirect
	github.com/mdlayher/socket v0.5.1 // indirect
	github.com/mdlayher/vsock v1.2.1 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/mwitkow/go-conntrack v0.0.0-20190716064945-2f068394615f // indirect
	github.com/siebenmann/go-kstat v0.0.0-20210513183136-173c9b0a9973 // indirect
	github.com/xhit/go-str2duration/v2 v2.1.0 // indirect
	go.uber.org/atomic v1.7.0 // indirect
	go.uber.org/multierr v1.6.0 // indirect
	go.yaml.in/yaml/v2 v2.4.4 // indirect
	golang.org/x/crypto v0.49.0 // indirect
	golang.org/x/net v0.52.0 // indirect
	golang.org/x/oauth2 v0.36.0 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/text v0.35.0 // indirect
	golang.org/x/time v0.15.0 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)
