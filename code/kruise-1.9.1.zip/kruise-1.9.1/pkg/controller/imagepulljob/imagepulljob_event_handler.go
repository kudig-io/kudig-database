/*
Copyright 2021 The Kruise Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package imagepulljob

import (
	"context"
	"reflect"

	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/client-go/util/workqueue"
	"k8s.io/klog/v2"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/event"
	"sigs.k8s.io/controller-runtime/pkg/handler"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"

	appsv1beta1 "github.com/openkruise/kruise/apis/apps/v1beta1"
	daemonutil "github.com/openkruise/kruise/pkg/daemon/util"
	kruiseutil "github.com/openkruise/kruise/pkg/util"
	utilclient "github.com/openkruise/kruise/pkg/util/client"
	"github.com/openkruise/kruise/pkg/util/expectations"
	utilimagejob "github.com/openkruise/kruise/pkg/util/imagejob"
)

type nodeImageEventHandler struct {
	client.Reader
}

var _ handler.TypedEventHandler[*appsv1beta1.NodeImage, reconcile.Request] = &nodeImageEventHandler{}

func (e *nodeImageEventHandler) Create(ctx context.Context, evt event.TypedCreateEvent[*appsv1beta1.NodeImage], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.Object
	e.handle(obj, q)
}

func (e *nodeImageEventHandler) Update(ctx context.Context, evt event.TypedUpdateEvent[*appsv1beta1.NodeImage], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.ObjectNew
	oldObj := evt.ObjectOld
	if obj.DeletionTimestamp != nil {
		e.handle(obj, q)
	} else {
		e.handleUpdate(obj, oldObj, q)
	}
}

func (e *nodeImageEventHandler) Delete(ctx context.Context, evt event.TypedDeleteEvent[*appsv1beta1.NodeImage], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.Object
	resourceVersionExpectations.Delete(obj)
	e.handle(obj, q)
}

func (e *nodeImageEventHandler) Generic(ctx context.Context, evt event.TypedGenericEvent[*appsv1beta1.NodeImage], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
}

func (e *nodeImageEventHandler) handle(nodeImage *appsv1beta1.NodeImage, q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	// Get jobs related to this NodeImage
	jobs, _, err := utilimagejob.GetActiveJobsForNodeImage(e.Reader, nodeImage, nil)
	if err != nil {
		klog.ErrorS(err, "Failed to get jobs for NodeImage", "nodeImageName", nodeImage.Name)
	}
	for _, j := range jobs {
		q.Add(reconcile.Request{NamespacedName: types.NamespacedName{Namespace: j.Namespace, Name: j.Name}})
	}
}

func (e *nodeImageEventHandler) handleUpdate(nodeImage, oldNodeImage *appsv1beta1.NodeImage, q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	// changedTags tracks which tags changed per image name.
	// nil value = image-level field change (PullSecrets/SandboxConfig/deleted), enqueue all jobs for that image
	// non-nil value = only specific tags changed, only enqueue jobs owning those tags
	changedTags := make(map[string]sets.String)
	tmpOldNodeImage := oldNodeImage.DeepCopy()

	for name, imageSpec := range nodeImage.Spec.Images {
		oldImageSpec := tmpOldNodeImage.Spec.Images[name]
		delete(tmpOldNodeImage.Spec.Images, name)
		if reflect.DeepEqual(imageSpec, oldImageSpec) {
			continue
		}
		if !reflect.DeepEqual(imageSpec.PullSecrets, oldImageSpec.PullSecrets) ||
			!reflect.DeepEqual(imageSpec.SandboxConfig, oldImageSpec.SandboxConfig) {
			changedTags[name] = nil
		} else {
			tags := getChangedSpecTags(imageSpec.Tags, oldImageSpec.Tags)
			if prev, ok := changedTags[name]; ok && prev != nil {
				changedTags[name] = prev.Union(tags)
			} else if !ok {
				changedTags[name] = tags
			}
		}
	}
	for name := range tmpOldNodeImage.Spec.Images {
		changedTags[name] = nil
	}

	for name, imageStatus := range nodeImage.Status.ImageStatuses {
		oldImageStatus := tmpOldNodeImage.Status.ImageStatuses[name]
		delete(tmpOldNodeImage.Status.ImageStatuses, name)
		if reflect.DeepEqual(imageStatus, oldImageStatus) {
			continue
		}
		tags := getChangedStatusTags(imageStatus.Tags, oldImageStatus.Tags)
		if prev, ok := changedTags[name]; ok && prev != nil {
			changedTags[name] = prev.Union(tags)
		} else if !ok {
			changedTags[name] = tags
		}
	}
	for name := range tmpOldNodeImage.Status.ImageStatuses {
		if _, ok := changedTags[name]; !ok {
			changedTags[name] = nil
		}
	}

	if klog.V(5).Enabled() {
		changedImages := make([]string, 0, len(changedTags))
		for name := range changedTags {
			changedImages = append(changedImages, name)
		}
		klog.InfoS("Found NodeImage updated", "nodeImageName", nodeImage.Name, "changedImages", changedImages)
	}

	// Get jobs related to this NodeImage
	newJobs, oldJobs, err := utilimagejob.GetActiveJobsForNodeImage(e.Reader, nodeImage, oldNodeImage)
	if err != nil {
		klog.ErrorS(err, "Failed to get jobs for NodeImage", "nodeImageName", nodeImage.Name)
	}
	diffSet := diffJobs(newJobs, oldJobs)
	for _, j := range newJobs {
		imageName, imageTag, err := daemonutil.NormalizeImageRefToNameTag(j.Spec.Image)
		if err != nil {
			klog.InfoS("Invalid image in job", "image", j.Spec.Image, "imagePullJob", klog.KObj(j))
			continue
		}
		tags, ok := changedTags[imageName]
		if !ok {
			continue
		}
		// nil means image-level change, enqueue all jobs for this image
		if tags == nil || tags.Has(imageTag) {
			diffSet[types.NamespacedName{Namespace: j.Namespace, Name: j.Name}] = struct{}{}
		}
	}
	for name := range diffSet {
		q.Add(reconcile.Request{NamespacedName: name})
	}
}

func getChangedSpecTags(newTags, oldTags []appsv1beta1.ImageTagSpec) sets.String {
	changed := sets.NewString()
	oldMap := make(map[string]appsv1beta1.ImageTagSpec, len(oldTags))
	for _, t := range oldTags {
		oldMap[t.Tag] = t
	}
	for _, t := range newTags {
		if old, ok := oldMap[t.Tag]; !ok || !reflect.DeepEqual(t, old) {
			changed.Insert(t.Tag)
		}
		delete(oldMap, t.Tag)
	}
	for tag := range oldMap {
		changed.Insert(tag)
	}
	return changed
}

func getChangedStatusTags(newTags, oldTags []appsv1beta1.ImageTagStatus) sets.String {
	changed := sets.NewString()
	oldMap := make(map[string]appsv1beta1.ImageTagStatus, len(oldTags))
	for _, t := range oldTags {
		oldMap[t.Tag] = t
	}
	for _, t := range newTags {
		if old, ok := oldMap[t.Tag]; !ok || !reflect.DeepEqual(t, old) {
			changed.Insert(t.Tag)
		}
		delete(oldMap, t.Tag)
	}
	for tag := range oldMap {
		changed.Insert(tag)
	}
	return changed
}

type podEventHandler struct {
	client.Reader
}

var _ handler.TypedEventHandler[*v1.Pod, reconcile.Request] = &podEventHandler{}

func (e *podEventHandler) Create(ctx context.Context, evt event.TypedCreateEvent[*v1.Pod], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.Object
	e.handle(obj, q)
}

func (e *podEventHandler) Update(ctx context.Context, evt event.TypedUpdateEvent[*v1.Pod], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.ObjectNew
	oldObj := evt.ObjectOld
	if obj.DeletionTimestamp != nil {
		e.handle(obj, q)
	} else {
		e.handleUpdate(obj, oldObj, q)
	}
}

func (e *podEventHandler) Delete(ctx context.Context, evt event.TypedDeleteEvent[*v1.Pod], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.Object
	e.handle(obj, q)
}

func (e *podEventHandler) Generic(ctx context.Context, evt event.TypedGenericEvent[*v1.Pod], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
}

func (e *podEventHandler) handle(pod *v1.Pod, q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if pod.Spec.NodeName == "" {
		return
	}
	// Get jobs related to this Pod
	jobs, _, err := utilimagejob.GetActiveJobsForPod(e.Reader, pod, nil)
	if err != nil {
		klog.ErrorS(err, "Failed to get jobs for Pod", "pod", klog.KObj(pod))
	}
	for _, j := range jobs {
		q.Add(reconcile.Request{NamespacedName: types.NamespacedName{Namespace: j.Namespace, Name: j.Name}})
	}
}

func (e *podEventHandler) handleUpdate(pod, oldPod *v1.Pod, q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if pod.Spec.NodeName == "" {
		return
	}
	if pod.Spec.NodeName == oldPod.Spec.NodeName && reflect.DeepEqual(pod.Labels, oldPod.Labels) {
		return
	}
	// Get jobs related to this NodeImage
	newJobs, oldJobs, err := utilimagejob.GetActiveJobsForPod(e.Reader, pod, oldPod)
	if err != nil {
		klog.ErrorS(err, "Failed to get jobs for Pod", "pod", klog.KObj(pod))
	}
	if oldPod.Spec.NodeName == "" {
		for _, j := range newJobs {
			q.Add(reconcile.Request{NamespacedName: types.NamespacedName{Namespace: j.Namespace, Name: j.Name}})
		}
		return
	}
	diffSet := diffJobs(newJobs, oldJobs)
	for name := range diffSet {
		q.Add(reconcile.Request{NamespacedName: name})
	}
}

type secretEventHandler struct {
	client.Reader
}

var _ handler.TypedEventHandler[*v1.Secret, reconcile.Request] = &secretEventHandler{}

func (e *secretEventHandler) Create(ctx context.Context, evt event.TypedCreateEvent[*v1.Secret], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	obj := evt.Object
	e.handle(obj, q)
}

func (e *secretEventHandler) Update(ctx context.Context, evt event.TypedUpdateEvent[*v1.Secret], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	newObj := evt.ObjectNew
	oldObj := evt.ObjectOld
	e.handleUpdate(newObj, oldObj, q)
}

func (e *secretEventHandler) Delete(ctx context.Context, evt event.TypedDeleteEvent[*v1.Secret], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
}

func (e *secretEventHandler) Generic(ctx context.Context, evt event.TypedGenericEvent[*v1.Secret], q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
}

func (e *secretEventHandler) handle(secret *v1.Secret, q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if secret != nil && secret.Namespace == kruiseutil.GetKruiseDaemonConfigNamespace() {
		jobKeySet := getReferencingJobsFromSecret(secret)
		klog.V(5).InfoS("Observed Secret created", "secret", klog.KObj(secret), "secretUID", secret.UID, "jobRefs", jobKeySet)
		for _, ref := range jobKeySet.UnsortedList() {
			scaleExpectations.ObserveScale(ref.String(), expectations.Create, secret.Name)
		}
		return
	}

	if secret == nil || secret.DeletionTimestamp != nil {
		return
	}
	// Get jobs related to this Secret
	jobKeys, err := e.getActiveJobKeysForSecret(secret)
	if err != nil {
		klog.ErrorS(err, "Failed to get jobs for Secret", "secret", klog.KObj(secret))
		return
	}
	for _, jKey := range jobKeys {
		q.Add(reconcile.Request{NamespacedName: jKey})
	}
}

func (e *secretEventHandler) handleUpdate(secretNew, secretOld *v1.Secret, q workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if secretNew != nil && secretNew.Namespace == kruiseutil.GetKruiseDaemonConfigNamespace() {
		jobKeySet := getReferencingJobsFromSecret(secretNew)
		for _, ref := range jobKeySet.UnsortedList() {
			scaleExpectations.ObserveScale(ref.String(), expectations.Create, secretNew.Name)
		}
		return
	}

	if secretOld == nil || secretNew == nil || secretNew.DeletionTimestamp != nil ||
		(reflect.DeepEqual(secretNew.Data, secretOld.Data) && reflect.DeepEqual(secretNew.StringData, secretOld.StringData)) {
		return
	}
	// Get jobs related to this Secret
	jobKeys, err := e.getActiveJobKeysForSecret(secretNew)
	if err != nil {
		klog.ErrorS(err, "Failed to get jobs for Secret", "secret", klog.KObj(secretNew))
	}
	for _, jKey := range jobKeys {
		q.Add(reconcile.Request{NamespacedName: jKey})
	}
}

func (e *secretEventHandler) getActiveJobKeysForSecret(secret *v1.Secret) ([]types.NamespacedName, error) {
	jobLister := &appsv1beta1.ImagePullJobList{}
	if err := e.List(context.TODO(), jobLister, client.InNamespace(secret.Namespace), utilclient.DisableDeepCopy); err != nil {
		return nil, err
	}
	var jobKeys []types.NamespacedName
	for i := range jobLister.Items {
		job := &jobLister.Items[i]
		if job.DeletionTimestamp != nil {
			continue
		}
		if jobContainsSecret(job, secret.Name) {
			jobKeys = append(jobKeys, types.NamespacedName{Namespace: job.Namespace, Name: job.Name})
		}
	}
	return jobKeys, nil
}

func jobContainsSecret(job *appsv1beta1.ImagePullJob, secretName string) bool {
	for _, s := range job.Spec.PullSecrets {
		if secretName == s {
			return true
		}
	}
	return false
}

func diffJobs(newJobs, oldJobs []*appsv1beta1.ImagePullJob) set {
	setNew := make(set, len(newJobs))
	setOld := make(set, len(oldJobs))
	for _, j := range newJobs {
		setNew[types.NamespacedName{Namespace: j.Namespace, Name: j.Name}] = struct{}{}
	}
	for _, j := range oldJobs {
		setOld[types.NamespacedName{Namespace: j.Namespace, Name: j.Name}] = struct{}{}
	}
	ret := make(set)
	for name, v := range setNew {
		if _, ok := setOld[name]; !ok {
			ret[name] = v
		}
	}
	for name, v := range setOld {
		if _, ok := setNew[name]; !ok {
			ret[name] = v
		}
	}
	return ret
}

type set map[types.NamespacedName]struct{}
