/*
Copyright 2021 The Kruise Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package pub

import v1 "k8s.io/api/core/v1"

const (
	// KruisePodReadyConditionType can support multiple writers, such as:
	// - ContainerRecreateRequest;
	// - Workload controller, including CloneSet, Advanced StatefulSet, Advanced Daemonset.
	//
	// If its corresponding condition status was set to "False" by multiple writers,
	// the condition status will be considered as "True" only when all these writers
	// set it to "True".
	KruisePodReadyConditionType v1.PodConditionType = "KruisePodReady"
)
