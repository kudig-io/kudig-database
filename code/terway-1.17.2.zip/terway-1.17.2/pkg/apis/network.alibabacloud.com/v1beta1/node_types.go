/*
Copyright 2024 Terway Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1beta1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// NetworkInterfaceTrafficMode represents the traffic mode of the network interface.
// +kubebuilder:validation:Enum=Standard;HighPerformance
type NetworkInterfaceTrafficMode string

const (
	NetworkInterfaceTrafficModeStandard        NetworkInterfaceTrafficMode = "Standard"
	NetworkInterfaceTrafficModeHighPerformance NetworkInterfaceTrafficMode = "HighPerformance"
)

// IPStatus representing the status of an IP address.
// +kubebuilder:validation:Enum=Valid;Invalid;Deleting
type IPStatus string

const (
	IPStatusValid    IPStatus = "Valid"
	IPStatusInvalid  IPStatus = "Invalid"
	IPStatusDeleting IPStatus = "Deleting"
)

// +kubebuilder:validation:Enum=ordered;random;most
type SelectionPolicy string

// VSwitch Selection Policy
const (
	VSwitchSelectionPolicyOrdered SelectionPolicy = "ordered"
	VSwitchSelectionPolicyRandom  SelectionPolicy = "random"
	VSwitchSelectionPolicyMost    SelectionPolicy = "most"
)

// IPPrefixStatus representing the status of an IP address.
// +kubebuilder:validation:Enum=Valid;Frozen;Invalid;Deleting
type IPPrefixStatus string

const (
	IPPrefixStatusValid    IPPrefixStatus = "Valid"
	IPPrefixStatusFrozen   IPPrefixStatus = "Frozen"
	IPPrefixStatusInvalid  IPPrefixStatus = "Invalid"
	IPPrefixStatusDeleting IPPrefixStatus = "Deleting"
)

type NodeMetadata struct {
	// +kubebuilder:validation:Required
	RegionID string `json:"regionID,omitempty"`
	// +kubebuilder:validation:Required
	InstanceType string `json:"instanceType,omitempty"`
	// +kubebuilder:validation:Required
	InstanceID string `json:"instanceID,omitempty"`
	// +kubebuilder:validation:Required
	ZoneID string `json:"zoneID,omitempty"`
}

type NodeCap struct {
	Adapters              int           `json:"adapters,omitempty"`
	EriQuantity           int           `json:"eriQuantity,omitempty"`
	TotalAdapters         int           `json:"totalAdapters,omitempty"`
	IPv4PerAdapter        int           `json:"ipv4PerAdapter,omitempty"`
	IPv6PerAdapter        int           `json:"ipv6PerAdapter,omitempty"`
	MemberAdapterLimit    int           `json:"memberAdapterLimit,omitempty"`
	MaxMemberAdapterLimit int           `json:"maxMemberAdapterLimit,omitempty"`
	InstanceBandwidthRx   int           `json:"instanceBandwidthRx,omitempty"`
	InstanceBandwidthTx   int           `json:"instanceBandwidthTx,omitempty"`
	NetworkCards          []NetworkCard `json:"networkCards,omitempty"`
	NetworkCardsCount     *int          `json:"networkCardsCount,omitempty"`
}

type NetworkCard struct {
	Index int `json:"index,omitempty"`
}

type ENISpec struct {
	Tag       map[string]string `json:"tag,omitempty"`
	TagFilter map[string]string `json:"tagFilter,omitempty"`
	// +kubebuilder:validation:Required
	VSwitchOptions []string `json:"vSwitchOptions,omitempty"`
	// +kubebuilder:validation:Required
	SecurityGroupIDs []string `json:"securityGroupIDs,omitempty"`
	ResourceGroupID  string   `json:"resourceGroupID,omitempty"`
	EnableIPv4       bool     `json:"enableIPv4,omitempty"`
	EnableIPv6       bool     `json:"enableIPv6,omitempty"`
	EnableERDMA      bool     `json:"enableERDMA,omitempty"`
	EnableTrunk      bool     `json:"enableTrunk,omitempty"`
	// +kubebuilder:validation:Required
	// +kubebuilder:default:most
	VSwitchSelectPolicy SelectionPolicy `json:"vSwitchSelectPolicy,omitempty"`

	// EnableIPPrefix indicates whether prefix-based IPAM is enabled for this node.
	// This field is immutable after the Node CR is created.
	EnableIPPrefix bool `json:"enableIPPrefix,omitempty"`

	// IPv4PrefixCount specifies the total number of IPv4 prefixes to allocate across all ENIs.
	// Effective in IPv4 single-stack and dual-stack modes.
	IPv4PrefixCount int `json:"ipv4PrefixCount,omitempty"`

	// IPv6PrefixCount specifies the total number of IPv6 prefixes to allocate.
	// Only effective in IPv6 single-stack mode. Valid values: 0 or 1.
	// In dual-stack mode this field is ignored; each ENI automatically gets one IPv6 prefix.
	IPv6PrefixCount int `json:"ipv6PrefixCount,omitempty"`
}

type PoolSpec struct {
	// +kubebuilder:validation:Minimum=0
	MaxPoolSize int `json:"maxPoolSize,omitempty"`
	// +kubebuilder:validation:Minimum=0
	MinPoolSize int `json:"minPoolSize,omitempty"`

	PoolSyncPeriod string `json:"poolSyncPeriod,omitempty"`

	Reclaim *IPReclaimPolicy `json:"reclaim,omitempty"`

	// +kubebuilder:validation:Minimum=0
	WarmUpSize int `json:"warmUpSize,omitempty"`
}

type IPReclaimPolicy struct {
	// After specifies the duration an IP must be idle before it is eligible for reclamation.
	// Examples: "300s", "5m", "1h"
	// +optional
	After *metav1.Duration `json:"after,omitempty"`

	// Interval specifies the time interval between IP reclamation checks.
	// +optional
	Interval *metav1.Duration `json:"interval,omitempty"`

	// BatchSize specifies the maximum number of IPs to reclaim in a single batch.
	// +optional
	BatchSize int `json:"batchSize,omitempty"`

	// +optional
	JitterFactor string `json:"jitterFactor,omitempty"`
}

type Flavor struct {
	NetworkInterfaceType        ENIType                     `json:"networkInterfaceType"`
	NetworkInterfaceTrafficMode NetworkInterfaceTrafficMode `json:"networkInterfaceTrafficMode"`

	// +kubebuilder:validation:Minimum=0
	Count int `json:"count"`
}

// NodeSpec defines the desired state of Node
type NodeSpec struct {
	NodeMetadata NodeMetadata `json:"nodeMetadata,omitempty"`
	NodeCap      NodeCap      `json:"nodeCap,omitempty"`
	Datapath     *Datapath    `json:"datapath,omitempty"`
	ENISpec      *ENISpec     `json:"eni,omitempty"`
	Pool         *PoolSpec    `json:"pool,omitempty"`
	// Flavor guide the controller to generate eni as expected
	Flavor []Flavor `json:"flavor,omitempty"`
}

type IP struct {
	// +kubebuilder:validation:Required
	IP string `json:"ip"`
	// +kubebuilder:validation:Required
	Primary bool `json:"primary"`
	// +kubebuilder:validation:Required
	Status IPStatus `json:"status"`
	// Add the pod ID
	PodID string `json:"podID,omitempty"`
	// Add pod UID for validate
	PodUID string `json:"podUID,omitempty"`

	IPName string `json:"ipName,omitempty"`
}

type IPMap map[string]*IP

type IPPrefix struct {
	Prefix         string         `json:"prefix"`
	Status         IPPrefixStatus `json:"status"`
	FrozenExpireAt metav1.Time    `json:"frozenExpireAt,omitempty"`
}

type Nic struct {
	// +kubebuilder:validation:Required
	ID string `json:"id"`
	// +kubebuilder:validation:Required
	Status string `json:"status"`

	MacAddress string `json:"macAddress,omitempty"`

	VSwitchID string `json:"vSwitchID,omitempty"`

	SecurityGroupIDs []string `json:"securityGroupIDs,omitempty"`

	PrimaryIPAddress string `json:"primaryIPAddress,omitempty"`

	NetworkInterfaceTrafficMode NetworkInterfaceTrafficMode `json:"networkInterfaceTrafficMode,omitempty"`

	NetworkInterfaceType ENIType `json:"networkInterfaceType,omitempty"`

	IPv4 map[string]*IP `json:"ipv4,omitempty"`
	IPv6 map[string]*IP `json:"ipv6,omitempty"`

	IPv4Prefix []IPPrefix `json:"ipv4Prefix,omitempty"`
	IPv6Prefix []IPPrefix `json:"ipv6Prefix,omitempty"`

	IPv4CIDR string `json:"ipv4CIDR,omitempty"`

	IPv6CIDR string `json:"ipv6CIDR,omitempty"`

	Conditions map[string]Condition `json:"conditions,omitempty"`
}

type Condition struct {
	ObservedTime metav1.Time `json:"observedTime,omitempty"`
	Message      string      `json:"message,omitempty"`
}

// DatapathType
// +kubebuilder:validation:Enum=veth;ipvlan;datapathv2
type DatapathType string

const (
	DatapathTypeVeth       DatapathType = "veth"
	DatapathTypeIPVlan     DatapathType = "ipvlan"
	DatapathTypeDatapathV2 DatapathType = "datapathv2"
)

type Datapath struct {
	Type DatapathType `json:"type,omitempty"`
}

// NodeStatus defines the observed state of Node
type NodeStatus struct {
	NextSyncOpenAPITime   metav1.Time     `json:"nextSyncOpenAPITime,omitempty"`
	LastSyncOpenAPITime   metav1.Time     `json:"lastSyncOpenAPITime,omitempty"`
	LastModifiedTime      metav1.Time     `json:"lastModifiedTime,omitempty"`
	NextIdleIPReclaimTime metav1.Time     `json:"nextIdleIPReclaimTime,omitempty"`
	NetworkInterfaces     map[string]*Nic `json:"networkInterfaces,omitempty"`

	WarmUpTarget         int  `json:"warmUpTarget,omitempty"`
	WarmUpAllocatedCount int  `json:"warmUpAllocatedCount,omitempty"`
	WarmUpCompleted      bool `json:"warmUpCompleted,omitempty"`
}

// +genclient
// +genclient:nonNamespaced
//+kubebuilder:object:root=true
//+kubebuilder:subresource:status
//+kubebuilder:resource:scope=Cluster

// Node is the Schema for the nodes API
type Node struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   NodeSpec   `json:"spec,omitempty"`
	Status NodeStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// NodeList contains a list of Node
type NodeList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []Node `json:"items"`
}
