package feature

import (
	"k8s.io/apimachinery/pkg/util/runtime"
	"k8s.io/component-base/featuregate"

	utilfeature "k8s.io/apiserver/pkg/util/feature"
)

func init() {
	runtime.Must(utilfeature.DefaultMutableFeatureGate.Add(defaultKubernetesFeatureGates))
}

const (
	// AutoDataPathV2 enable the new datapath feature.
	AutoDataPathV2 featuregate.Feature = "AutoDataPathV2"

	EFLO featuregate.Feature = "EFLO"

	KubeProxyReplacement featuregate.Feature = "KubeProxyReplacement"

	WriteCNIConfFirst featuregate.Feature = "WriteCNIConfFirst"

	// ENIAttributeBasic switches single-ENI queries from DescribeNetworkInterfaces
	// to DescribeNetworkInterfaceAttribute(Attribute='basic') for faster responses.
	ENIAttributeBasic featuregate.Feature = "ENIAttributeBasic"
)

var defaultKubernetesFeatureGates = map[featuregate.Feature]featuregate.FeatureSpec{
	AutoDataPathV2:       {Default: true, PreRelease: featuregate.Alpha},
	EFLO:                 {Default: true, PreRelease: featuregate.Alpha},
	KubeProxyReplacement: {Default: false, PreRelease: featuregate.Alpha},
	WriteCNIConfFirst:    {Default: false, PreRelease: featuregate.Alpha},
	ENIAttributeBasic:    {Default: false, PreRelease: featuregate.Alpha},
}
