// This is a generated file. Do not edit directly.

module k8s.io/kubectl

go 1.26.0

godebug default=go1.26

require (
	github.com/MakeNowJust/heredoc v1.0.0
	github.com/chai2010/gettext-go v1.0.2
	github.com/distribution/reference v0.6.0
	github.com/exponent-io/jsonpath v0.0.0-20210407135951-1de76d718b3f
	github.com/fatih/camelcase v1.0.0
	github.com/go-openapi/jsonreference v0.21.4
	github.com/google/gnostic-models v0.7.0
	github.com/google/go-cmp v0.7.0
	github.com/jonboulle/clockwork v0.5.0
	github.com/liggitt/tabwriter v0.0.0-20181228230101-89fcab3d43de
	github.com/lithammer/dedent v1.1.0
	github.com/mitchellh/go-wordwrap v1.0.1
	github.com/moby/term v0.5.2
	github.com/onsi/ginkgo/v2 v2.28.3
	github.com/onsi/gomega v1.40.0
	github.com/russross/blackfriday/v2 v2.1.0
	github.com/spf13/cobra v1.10.2
	github.com/spf13/pflag v1.0.10
	github.com/stretchr/testify v1.11.1
	go.yaml.in/yaml/v2 v2.4.4
	golang.org/x/sys v0.45.0
	golang.org/x/text v0.37.0
	gopkg.in/evanphx/json-patch.v4 v4.13.0
	k8s.io/api v0.0.0-20260708015948-643f0cd3c4da
	k8s.io/apimachinery v0.0.0-20260708015502-54f40c0d9f0b
	k8s.io/cli-runtime v0.0.0-20260708030233-ec915cc91693
	k8s.io/client-go v0.0.0-20260708020624-fd85b06595e6
	k8s.io/component-base v0.0.0-20260708022243-9dc6cf0c75fe
	k8s.io/component-helpers v0.0.0-20260708022554-af578fb8e56b
	k8s.io/klog/v2 v2.140.0
	k8s.io/kube-openapi v0.0.0-20260618221249-bc653b64f974
	k8s.io/metrics v0.0.0-20260708025952-5e2495aab61f
	k8s.io/streaming v0.0.0-20260626172358-68009e8e6aa5
	k8s.io/utils v0.0.0-20260626114624-be93311217bd
	sigs.k8s.io/json v0.0.0-20250730193827-2d320260d730
	sigs.k8s.io/kustomize/kustomize/v5 v5.8.1
	sigs.k8s.io/kustomize/kyaml v0.21.1
	sigs.k8s.io/randfill v1.0.0
	sigs.k8s.io/structured-merge-diff/v6 v6.4.2
	sigs.k8s.io/yaml v1.6.0
)

require (
	github.com/Azure/go-ansiterm v0.0.0-20250102033503-faa5f7b0171c // indirect
	github.com/Masterminds/semver/v3 v3.4.0 // indirect
	github.com/blang/semver/v4 v4.0.0 // indirect
	github.com/davecgh/go-spew v1.1.2-0.20180830191138-d8f796af33cc // indirect
	github.com/emicklei/go-restful/v3 v3.13.0 // indirect
	github.com/fxamacker/cbor/v2 v2.9.1 // indirect
	github.com/go-errors/errors v1.4.2 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-openapi/jsonpointer v0.22.4 // indirect
	github.com/go-openapi/swag v0.25.4 // indirect
	github.com/go-openapi/swag/cmdutils v0.25.4 // indirect
	github.com/go-openapi/swag/conv v0.25.4 // indirect
	github.com/go-openapi/swag/fileutils v0.25.4 // indirect
	github.com/go-openapi/swag/jsonname v0.25.4 // indirect
	github.com/go-openapi/swag/jsonutils v0.25.4 // indirect
	github.com/go-openapi/swag/loading v0.25.4 // indirect
	github.com/go-openapi/swag/mangling v0.25.4 // indirect
	github.com/go-openapi/swag/netutils v0.25.4 // indirect
	github.com/go-openapi/swag/stringutils v0.25.4 // indirect
	github.com/go-openapi/swag/typeutils v0.25.4 // indirect
	github.com/go-openapi/swag/yamlutils v0.25.4 // indirect
	github.com/go-task/slim-sprig/v3 v3.0.0 // indirect
	github.com/google/btree v1.1.3 // indirect
	github.com/google/pprof v0.0.0-20260402051712-545e8a4df936 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/gorilla/websocket v1.5.4-0.20250319132907-e064f32e3674 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/moby/spdystream v0.5.1 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.3-0.20250322232337-35a7c28c31ee // indirect
	github.com/monochromegane/go-gitignore v0.0.0-20200626010858-205db1a8cc00 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/mxk/go-flowrate v0.0.0-20140419014527-cca7078d478f // indirect
	github.com/opencontainers/go-digest v1.0.0 // indirect
	github.com/peterbourgon/diskv v2.0.1+incompatible // indirect
	github.com/pmezard/go-difflib v1.0.1-0.20181226105442-5d4384ee4fb2 // indirect
	github.com/x448/float16 v0.8.4 // indirect
	github.com/xlab/treeprint v1.2.0 // indirect
	go.yaml.in/yaml/v3 v3.0.4 // indirect
	golang.org/x/mod v0.35.0 // indirect
	golang.org/x/net v0.55.1-0.20260602153038-42abb857022c // indirect
	golang.org/x/oauth2 v0.36.0 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/term v0.43.0 // indirect
	golang.org/x/time v0.15.0 // indirect
	golang.org/x/tools v0.44.0 // indirect
	google.golang.org/protobuf v1.36.12-0.20260120151049-f2248ac996af // indirect
	gopkg.in/inf.v0 v0.9.1 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
	sigs.k8s.io/kustomize/api v0.21.1 // indirect
)
