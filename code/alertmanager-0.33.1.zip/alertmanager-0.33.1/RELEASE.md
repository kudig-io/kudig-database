# Releases
This page describes the release process and the currently planned schedule for upcoming releases as well as the respective release shepherd. Release shepherds are chosen on a voluntary basis.

## Release Schedule

Release cadence of first pre-releases being cut is 12 weeks.

| release series | date (year-month-day) | release shepherd                          |
|----------------|-----------------------|-------------------------------------------|
| v0.26          | 2023-08-23            | Josh Abreu (Github: @gotjosh)             |
| v0.27          | 2024-02-28            | Josh Abreu (Github: @gotjosh)             |
| v0.28          | 2024-05-28            | Josh Abreu (Github: @gotjosh)             |
| v0.29          | 2025-11-01            | Joe Adams (Github: @sysadmind)            |
| v0.30          | 2025-12-12            | Solomon Jacobs (Github: @SoloJacobs)      |
| v0.31          | 2026-01-31            | Solomon Jacobs (Github: @SoloJacobs)      |
| v0.32          | 2026-04-08            | Solomon Jacobs (Github: @SoloJacobs)      |
| v0.33          | 2026-06-08            | **volunteer welcome**                     |

If you are interested in volunteering please create a pull request against the [prometheus/alertmanager](https://github.com/prometheus/alertmanager) repository and propose yourself for the release of your choice.

If you'd like to know more about the shepherd responsibilities or the release instructions please [refer to the `RELEASE.MD`](https://github.com/prometheus/prometheus/blob/main/RELEASE.md) in [prometheus/prometheus](https://github.com/prometheus/prometheus).
