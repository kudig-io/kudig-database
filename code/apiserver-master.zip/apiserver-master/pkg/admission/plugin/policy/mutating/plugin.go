/*
Copyright 2024 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package mutating

import (
	"context"
	"io"

	celgo "github.com/google/cel-go/cel"

	v1 "k8s.io/api/admissionregistration/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/managedfields"
	"k8s.io/apiserver/pkg/admission"
	"k8s.io/apiserver/pkg/admission/initializer"
	"k8s.io/apiserver/pkg/admission/plugin/cel"
	"k8s.io/apiserver/pkg/admission/plugin/manifest/metrics"
	"k8s.io/apiserver/pkg/admission/plugin/policy/config"
	"k8s.io/apiserver/pkg/admission/plugin/policy/generic"
	"k8s.io/apiserver/pkg/admission/plugin/policy/manifest/source"
	"k8s.io/apiserver/pkg/admission/plugin/policy/matching"
	"k8s.io/apiserver/pkg/admission/plugin/policy/mutating/patch"
	"k8s.io/apiserver/pkg/admission/plugin/webhook/matchconditions"
	"k8s.io/apiserver/pkg/authorization/authorizer"
	"k8s.io/apiserver/pkg/features"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes"
	"k8s.io/component-base/featuregate"
)

const (
	// PluginName indicates the name of admission plug-in
	PluginName = "MutatingAdmissionPolicy"
)

// Register registers a plugin
func Register(plugins *admission.Plugins) {
	plugins.Register(PluginName, func(configFile io.Reader) (admission.Interface, error) {
		return NewPlugin(configFile)
	})
}

type Policy = v1.MutatingAdmissionPolicy
type PolicyBinding = v1.MutatingAdmissionPolicyBinding

type PolicyHook = generic.PolicyHook[*Policy, *PolicyBinding, PolicyEvaluator]

type Mutator struct {
}
type MutationEvaluationFunc func(
	ctx context.Context,
	matchedResource schema.GroupVersionResource,
	versionedAttr *admission.VersionedAttributes,
	o admission.ObjectInterfaces,
	versionedParams runtime.Object,
	namespace *corev1.Namespace,
	typeConverter managedfields.TypeConverter,
	runtimeCELCostBudget int64,
	authorizer authorizer.UnconditionalAuthorizer,
) (runtime.Object, error)

type PolicyEvaluator struct {
	Matcher            matchconditions.Matcher
	Mutators           []patch.Patcher
	CompositedCompiler *cel.CompositedCompiler
	Error              error
}

// Plugin is an implementation of admission.Interface.
type Plugin struct {
	*generic.Plugin[PolicyHook]
}

var _ admission.Interface = &Plugin{}
var _ admission.MutationInterface = &Plugin{}
var _ initializer.WantsManifestLoaders = &Plugin{}

// SetManifestLoaders provides the manifest load functions for scheme-based defaulting and validation.
func (a *Plugin) SetManifestLoaders(loaders *initializer.ManifestLoaders) {
	if loaders == nil || loaders.LoadMutatingPolicyManifests == nil {
		return
	}
	loadFunc := loaders.LoadMutatingPolicyManifests
	a.SetStaticSourceFactory(func(manifestsDir string) (generic.ReloadableSource[PolicyHook], error) {
		staticSource := source.NewStaticPolicySource(manifestsDir, a.GetAPIServerID(),
			func(p *v1.MutatingAdmissionPolicy) (PolicyEvaluator, error) {
				e := compilePolicy(p)
				if e.Error != nil {
					return PolicyEvaluator{}, e.Error
				}
				return e, nil
			},
			func(dir string) ([]*v1.MutatingAdmissionPolicy, []*v1.MutatingAdmissionPolicyBinding, string, error) {
				return loadFunc(dir)
			},
			func(b *v1.MutatingAdmissionPolicyBinding) string { return b.Spec.PolicyName },
			metrics.MAPManifestType,
		)
		if err := staticSource.LoadInitial(); err != nil {
			return nil, err
		}
		return staticSource, nil
	})
}

// NewPlugin returns a generic admission webhook plugin.
func NewPlugin(configFile io.Reader) (*Plugin, error) {
	cfg, err := config.LoadMutatingConfig(configFile)
	if err != nil {
		return nil, err
	}

	// There is no request body to mutate for DELETE, so this plugin never handles that operation.
	handler := admission.NewHandler(admission.Create, admission.Update, admission.Connect)
	res := &Plugin{}
	res.Plugin = generic.NewPlugin(
		handler,
		func(f informers.SharedInformerFactory, client kubernetes.Interface, dynamicClient dynamic.Interface, restMapper meta.RESTMapper) generic.Source[PolicyHook] {
			return generic.NewPolicySource(
				f.Admissionregistration().V1().MutatingAdmissionPolicies().Informer(),
				f.Admissionregistration().V1().MutatingAdmissionPolicyBindings().Informer(),
				NewMutatingAdmissionPolicyAccessor,
				NewMutatingAdmissionPolicyBindingAccessor,
				compilePolicy,
				//!TODO: Create a way to share param informers between
				// mutating/validating plugins
				f,
				dynamicClient,
				restMapper,
			)
		},
		func(a authorizer.UnconditionalAuthorizer, m *matching.Matcher, client kubernetes.Interface) generic.Dispatcher[PolicyHook] {
			return NewDispatcher(a, m, patch.NewTypeConverterManager(nil, client.Discovery().OpenAPIV3()))
		},
	)
	res.SetStaticManifestsDir(cfg.StaticManifestsDir)
	return res, nil
}

// Admit makes an admission decision based on the request attributes.
func (a *Plugin) Admit(ctx context.Context, attr admission.Attributes, o admission.ObjectInterfaces) error {
	return a.Plugin.Dispatch(ctx, attr, o)
}

func (a *Plugin) InspectFeatureGates(featureGates featuregate.FeatureGate) {
	a.Plugin.SetEnabled(featureGates.Enabled(features.MutatingAdmissionPolicy))
}

// Variable is a named expression for composition.
type Variable struct {
	Name       string
	Expression string
}

func (v *Variable) GetExpression() string {
	return v.Expression
}

func (v *Variable) ReturnTypes() []*celgo.Type {
	return []*celgo.Type{celgo.AnyType, celgo.DynType}
}

func (v *Variable) GetName() string {
	return v.Name
}
