/*
Copyright 2023 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cel

import (
	"context"
	"math"

	"github.com/google/cel-go/cel"
	"github.com/google/cel-go/common/types"
	"github.com/google/cel-go/common/types/ref"
	"github.com/google/cel-go/common/types/traits"

	v1 "k8s.io/api/admission/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/util/version"
	"k8s.io/apiserver/pkg/admission"
	apiservercel "k8s.io/apiserver/pkg/cel"
	"k8s.io/apiserver/pkg/cel/environment"
	"k8s.io/apiserver/pkg/cel/lazy"
)

const variablesTypeName = "kubernetes.variables"

// CompositedCompiler compiles expressions with variable composition.
type CompositedCompiler struct {
	Compiler
	ConditionCompiler
	MutatingCompiler

	state *compositionState
}

// CompositedConditionEvaluator provides evaluation of a condition expression with variable composition.
// The expressions must return a boolean.
type CompositedConditionEvaluator struct {
	ConditionEvaluator

	state *compositionState
}

// CompositedEvaluator provides evaluation of a single expression with variable composition.
// The types that may returned by the expression is determined at compilation time.
type CompositedEvaluator struct {
	MutatingEvaluator

	state *compositionState
}

func NewCompositedCompiler(envSet *environment.EnvSet) (*CompositedCompiler, error) {
	newMapType := apiservercel.NewObjectType(variablesTypeName, map[string]*apiservercel.DeclField{})

	newEnvSet, err := envSet.Extend(environment.VersionedOptions{
		IntroducedVersion: version.MajorMinor(1, 0),
		EnvOptions: []cel.EnvOption{
			cel.Variable("variables", newMapType.CelType()),
		},
		DeclTypes: []*apiservercel.DeclType{
			newMapType,
		},
	})
	if err != nil {
		return nil, err
	}

	state := &compositionState{
		mapType:           newMapType,
		EnvSet:            newEnvSet,
		compiledVariables: map[string]CompilationResult{},
	}

	compiler := NewCompiler(state.EnvSet)
	conditionCompiler := &conditionCompiler{compiler}
	mutation := &mutatingCompiler{compiler}
	return &CompositedCompiler{
		Compiler:          compiler,
		ConditionCompiler: conditionCompiler,
		MutatingCompiler:  mutation,
		state:             state,
	}, nil
}

// NewCompositedCompilerForTypeChecking creates a CompositedCompiler for type checking.
// It initializes the composition state but leaves the Compilers nil, as they are expected
// to be replaced by the caller (who is doing type checking).
func NewCompositedCompilerForTypeChecking(envSet *environment.EnvSet) (*CompositedCompiler, error) {
	newMapType := apiservercel.NewObjectType(variablesTypeName, map[string]*apiservercel.DeclField{})

	newEnvSet, err := envSet.Extend(environment.VersionedOptions{
		IntroducedVersion: version.MajorMinor(1, 0),
		EnvOptions: []cel.EnvOption{
			cel.Variable("variables", newMapType.CelType()),
		},
		DeclTypes: []*apiservercel.DeclType{
			newMapType,
		},
	})
	if err != nil {
		return nil, err
	}

	state := &compositionState{
		mapType:           newMapType,
		EnvSet:            newEnvSet,
		compiledVariables: map[string]CompilationResult{},
	}
	return &CompositedCompiler{
		state: state,
	}, nil
}

// Env returns the CEL environment for the given mode.
func (c *CompositedCompiler) Env(mode environment.Type) (*cel.Env, error) {
	return c.state.Env(mode)
}

func (c *CompositedCompiler) CreateContext(parent context.Context) CompositionContext {
	return c.state.CreateContext(parent)
}

func (c *CompositedCompiler) CompileAndStoreVariables(variables []NamedExpressionAccessor, options OptionalVariableDeclarations, mode environment.Type) {
	for _, v := range variables {
		_ = c.CompileAndStoreVariable(v, options, mode)
	}
}

func (c *CompositedCompiler) CompileAndStoreVariable(variable NamedExpressionAccessor, options OptionalVariableDeclarations, mode environment.Type) CompilationResult {
	result := c.Compiler.CompileCELExpression(variable, options, mode)
	c.state.AddField(variable.GetName(), result.OutputType)
	c.state.compiledVariables[variable.GetName()] = result
	return result
}

func (c *CompositedCompiler) CompileCondition(expressions []ExpressionAccessor, optionalDecls OptionalVariableDeclarations, envType environment.Type) ConditionEvaluator {
	condition := c.ConditionCompiler.CompileCondition(expressions, optionalDecls, envType)
	return &CompositedConditionEvaluator{
		ConditionEvaluator: condition,
		state:              c.state,
	}
}

// CompileEvaluator compiles an mutatingEvaluator for the given expression, options and environment.
func (c *CompositedCompiler) CompileMutatingEvaluator(expression ExpressionAccessor, optionalDecls OptionalVariableDeclarations, envType environment.Type) MutatingEvaluator {
	mutation := c.MutatingCompiler.CompileMutatingEvaluator(expression, optionalDecls, envType)
	return &CompositedEvaluator{
		MutatingEvaluator: mutation,
		state:             c.state,
	}
}

type compositionState struct {
	*environment.EnvSet

	mapType           *apiservercel.DeclType
	compiledVariables map[string]CompilationResult
}

func (c *compositionState) AddField(name string, celType *cel.Type) {
	c.mapType.Fields[name] = apiservercel.NewDeclField(name, convertCelTypeToDeclType(celType), true, nil, nil)
}

func (c *compositionState) CreateContext(parent context.Context) CompositionContext {
	return &compositionContext{
		Context: parent,
		state:   c,
	}
}

type CompositionContext interface {
	context.Context
	Variables(activation any) ref.Val
	GetAndResetCost() int64
}

type compositionContext struct {
	context.Context

	state           *compositionState
	accumulatedCost int64
}

func (c *compositionContext) Variables(activation any) ref.Val {
	lazyMap := lazy.NewMapValue(c.state.mapType)
	for name, result := range c.state.compiledVariables {
		accessor := &variableAccessor{
			name:       name,
			result:     result,
			activation: activation,
			context:    c,
		}
		lazyMap.Append(name, accessor.Callback)
	}
	return lazyMap
}

func (f *CompositedConditionEvaluator) ForInput(ctx context.Context, versionedAttr *admission.VersionedAttributes, request *v1.AdmissionRequest, optionalVars OptionalVariableBindings, namespace *corev1.Namespace, runtimeCELCostBudget int64) ([]EvaluationResult, int64, error) {
	ctx = f.state.CreateContext(ctx)
	return f.ConditionEvaluator.ForInput(ctx, versionedAttr, request, optionalVars, namespace, runtimeCELCostBudget)
}

func (c *compositionContext) reportCost(cost int64) {
	c.accumulatedCost += cost
}

func (c *compositionContext) GetAndResetCost() int64 {
	cost := c.accumulatedCost
	c.accumulatedCost = 0
	return cost
}

type variableAccessor struct {
	name       string
	result     CompilationResult
	activation any
	context    *compositionContext
}

func (a *variableAccessor) Callback(_ *lazy.MapValue) ref.Val {
	if a.result.Error != nil {
		return types.NewErr("composited variable %q fails to compile: %v", a.name, a.result.Error)
	}

	v, details, err := a.result.Program.ContextEval(a.context, a.activation)
	if details == nil {
		return types.NewErr("unable to get evaluation details of variable %q", a.name)
	}
	costPtr := details.ActualCost()
	if costPtr == nil {
		return types.NewErr("unable to calculate cost of variable %q", a.name)
	}
	cost := int64(*costPtr)
	if *costPtr > math.MaxInt64 {
		cost = math.MaxInt64
	}
	a.context.reportCost(cost)

	if err != nil {
		return types.NewErr("composited variable %q fails to evaluate: %v", a.name, err)
	}
	return v
}

// convertCelTypeToDeclType converts a cel.Type to DeclType, for the use of
// the TypeProvider and the cost estimator.
// List and map types are created on-demand with their parameters converted recursively.
func convertCelTypeToDeclType(celType *cel.Type) *apiservercel.DeclType {
	if celType == nil {
		return apiservercel.DynType
	}
	switch celType {
	case cel.AnyType:
		return apiservercel.AnyType
	case cel.BoolType:
		return apiservercel.BoolType
	case cel.BytesType:
		return apiservercel.BytesType
	case cel.DoubleType:
		return apiservercel.DoubleType
	case cel.DurationType:
		return apiservercel.DurationType
	case cel.IntType:
		return apiservercel.IntType
	case cel.NullType:
		return apiservercel.NullType
	case cel.StringType:
		return apiservercel.StringType
	case cel.TimestampType:
		return apiservercel.TimestampType
	case cel.UintType:
		return apiservercel.UintType
	default:
		if celType.HasTrait(traits.ContainerType) && celType.HasTrait(traits.IndexerType) {
			parameters := celType.Parameters()
			switch len(parameters) {
			case 1:
				elemType := convertCelTypeToDeclType(parameters[0])
				return apiservercel.NewListType(elemType, -1)
			case 2:
				keyType := convertCelTypeToDeclType(parameters[0])
				valueType := convertCelTypeToDeclType(parameters[1])
				return apiservercel.NewMapType(keyType, valueType, -1)
			}
		}
		return apiservercel.DynType
	}
}
