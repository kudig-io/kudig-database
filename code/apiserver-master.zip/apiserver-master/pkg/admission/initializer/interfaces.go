/*
Copyright 2017 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package initializer

import (
	admissionregistrationv1api "k8s.io/api/admissionregistration/v1"
	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apiserver/pkg/admission"
	"k8s.io/apiserver/pkg/authorization/authorizer"
	"k8s.io/apiserver/pkg/cel/openapi/resolver"
	quota "k8s.io/apiserver/pkg/quota/v1"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes"
	"k8s.io/component-base/compatibility"
	"k8s.io/component-base/featuregate"
)

// WantsExternalKubeClientSet defines a function which sets external ClientSet for admission plugins that need it
type WantsExternalKubeClientSet interface {
	SetExternalKubeClientSet(kubernetes.Interface)
	admission.InitializationValidator
}

// WantsExternalKubeInformerFactory defines a function which sets InformerFactory for admission plugins that need it
type WantsExternalKubeInformerFactory interface {
	SetExternalKubeInformerFactory(informers.SharedInformerFactory)
	admission.InitializationValidator
}

// WantsUnconditionalAuthorizer defines a function which sets authorizer.UnconditionalAuthorizer for admission plugins that need it.
type WantsUnconditionalAuthorizer interface {
	SetUnconditionalAuthorizer(authorizer.UnconditionalAuthorizer)
	admission.InitializationValidator
}

// WantsQuotaConfiguration defines a function which sets quota configuration for admission plugins that need it.
type WantsQuotaConfiguration interface {
	SetQuotaConfiguration(quota.Configuration)
	admission.InitializationValidator
}

// WantsDrainedNotification defines a function which sets the notification of where the apiserver
// has already been drained for admission plugins that need it.
// After receiving that notification, Admit/Validate calls won't be called anymore.
type WantsDrainedNotification interface {
	SetDrainedNotification(<-chan struct{})
	admission.InitializationValidator
}

// WantsFeatureGate defines a function which passes the featureGates for inspection by an admission plugin.
// Admission plugins should not hold a reference to the featureGates.  Instead, they should query a particular one
// and assign it to a simple bool in the admission plugin struct.
//
//	func (a *admissionPlugin) InspectFeatureGates(features featuregate.FeatureGate){
//	    a.myFeatureIsOn = features.Enabled("my-feature")
//	}
type WantsFeatures interface {
	InspectFeatureGates(featuregate.FeatureGate)
	admission.InitializationValidator
}

// WantsEffectiveVersion defines a function which passes the effective version for inspection by an admission plugin.
type WantsEffectiveVersion interface {
	InspectEffectiveVersion(compatibility.EffectiveVersion)
	admission.InitializationValidator
}

type WantsDynamicClient interface {
	SetDynamicClient(dynamic.Interface)
	admission.InitializationValidator
}

// WantsRESTMapper defines a function which sets RESTMapper for admission plugins that need it.
type WantsRESTMapper interface {
	SetRESTMapper(meta.RESTMapper)
	admission.InitializationValidator
}

// WantsSchemaResolver defines a function which sets the SchemaResolver for
// an admission plugin that needs it.
type WantsSchemaResolver interface {
	SetSchemaResolver(resolver resolver.SchemaResolver)
	admission.InitializationValidator
}

// WantsExcludedAdmissionResources defines a function which sets the ExcludedAdmissionResources
// for an admission plugin that needs it.
type WantsExcludedAdmissionResources interface {
	SetExcludedAdmissionResources(excludedAdmissionResources []schema.GroupResource)
	admission.InitializationValidator
}

// WantsAPIServerID defines a function which sets the API server ID for admission plugins
// that need it (e.g., for metrics labeling in HA setups).
type WantsAPIServerID interface {
	SetAPIServerID(apiServerID string)
	admission.InitializationValidator
}

// ValidatingWebhookManifestLoadFunc loads ValidatingWebhookConfiguration manifests from a directory.
type ValidatingWebhookManifestLoadFunc func(dir string) ([]*admissionregistrationv1api.ValidatingWebhookConfiguration, string, error)

// MutatingWebhookManifestLoadFunc loads MutatingWebhookConfiguration manifests from a directory.
type MutatingWebhookManifestLoadFunc func(dir string) ([]*admissionregistrationv1api.MutatingWebhookConfiguration, string, error)

// ValidatingPolicyManifestLoadFunc loads ValidatingAdmissionPolicy manifests from a directory.
type ValidatingPolicyManifestLoadFunc func(dir string) ([]*admissionregistrationv1api.ValidatingAdmissionPolicy, []*admissionregistrationv1api.ValidatingAdmissionPolicyBinding, string, error)

// MutatingPolicyManifestLoadFunc loads MutatingAdmissionPolicy manifests from a directory.
type MutatingPolicyManifestLoadFunc func(dir string) ([]*admissionregistrationv1api.MutatingAdmissionPolicy, []*admissionregistrationv1api.MutatingAdmissionPolicyBinding, string, error)

// ManifestLoaders provides functions to load admission configurations from static manifest files
// with scheme-based defaulting and validation.
type ManifestLoaders struct {
	// LoadValidatingWebhookManifests loads ValidatingWebhookConfiguration manifests.
	LoadValidatingWebhookManifests ValidatingWebhookManifestLoadFunc
	// LoadMutatingWebhookManifests loads MutatingWebhookConfiguration manifests.
	LoadMutatingWebhookManifests MutatingWebhookManifestLoadFunc
	// LoadValidatingPolicyManifests loads ValidatingAdmissionPolicy manifests.
	LoadValidatingPolicyManifests ValidatingPolicyManifestLoadFunc
	// LoadMutatingPolicyManifests loads MutatingAdmissionPolicy manifests.
	LoadMutatingPolicyManifests MutatingPolicyManifestLoadFunc
}

// WantsManifestLoaders is implemented by admission plugins that load configurations
// from static manifest files and need scheme-based defaulting and validation.
type WantsManifestLoaders interface {
	SetManifestLoaders(loaders *ManifestLoaders)
}
